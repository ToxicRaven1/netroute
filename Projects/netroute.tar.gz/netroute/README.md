# netroute

Per-process traffic routing across network interfaces on Windows, in Rust.

Each app's traffic leaves on the interface you assign it, whatever the
destination. A VPN adapter counts as just another interface.

## Why it needs source NAT (read this first)

Windows picks the outbound adapter from the packet **destination**, not the
source. So to force an app out a chosen adapter, the program rewrites the packet
**source IP** to that adapter's IP and reinjects on that adapter's ifindex.

That change breaks the return path: the reply comes back to the new IP, but the
app's socket waits at the old IP. So the program also rewrites the reply back.
This two-way rewrite is per-process source NAT. It is the core of the design.
See `src/engine/nat.rs`.

## How it works

Two WinDivert handles run at once:

- **FLOW layer** (passive): learns `connection -> PID -> process name`.
- **NETWORK layer** (active): per packet, finds the process, picks the
  interface, applies the NAT, reinjects.

The pure logic — flow table, NAT table, route decision, interface matching — is
unit-tested and does not need Windows. The two capture loops and the adapter
enumeration touch Windows APIs; those spots are marked in the code.

## Layout

| File | Role |
|------|------|
| `src/config.rs` | TOML config: interfaces + process→interface map. Tested. |
| `src/interfaces.rs` | Resolve adapter names to live ifindex/IP. Matching is tested; the OS read is marked. |
| `src/engine/flow.rs` | Connection→process table. Tested. |
| `src/engine/nat.rs` | Two-way source NAT. Tested. |
| `src/engine/mod.rs` | Decisions (tested) + the two WinDivert loops (marked). |
| `src/gui/mod.rs` | Classic Win32 GUI (native-windows-gui). Marked. |
| `src/main.rs` | Start-up order and threads. |

## Build

On a Windows machine with Rust and the MSVC toolchain:

```
cargo test        # runs the pure-logic tests now, no driver needed
cargo build --release
```

Put `WinDivert.dll`, `WinDivert64.sys`, and `config.toml` next to the exe.
Run as Administrator (WinDivert loads a driver). Ship an app manifest with
`requireAdministrator` so the user gets the prompt at launch.

## Status

- Done and tested: config, interface matching, flow table, NAT table, route
  decisions.
- To fill in on a Windows box (marked in code): `enumerate_adapters`,
  `spawn_flow_reader`, `spawn_network_worker`, `gui::run`.

## Known hard points, in order

1. **Checksums.** Recompute IPv4 and TCP/UDP checksums after any header edit, or
   the peer drops the packet and the connection stalls. `WinDivertHelperCalcChecksums`
   does it.
2. **Adapter reconnect.** On a reconnect the ifindex or IP can change. Re-run
   `resolve` on a network-change event and swap the interface table. The route
   map and NAT table stay as they are.
3. **Fail closed.** If an app's assigned interface is down, do not fall back to a
   leaky default without saying so. The engine drops rather than leak; decide
   the policy you want and make it explicit.
4. **IPv6.** This design is IPv4. If the controlled network offers IPv6, apps may
   use it and bypass the rules. Either add an IPv6 path or block IPv6 on the
   adapters you route.
5. **Performance.** The main lever is a tight WinDivert filter so the kernel does
   not hand you packets you only pass through.
